import 'package:flutter/material.dart';

/// ResponsiveHelper provides utilities for responsive layout adaptation
/// based on screen size using MediaQuery.
class ResponsiveHelper {
  final BuildContext context;

  ResponsiveHelper(this.context);

  /// Get screen width
  double get screenWidth => MediaQuery.of(context).size.width;

  /// Get screen height
  double get screenHeight => MediaQuery.of(context).size.height;

  /// Check if device is mobile (width < 600)
  bool get isMobile => screenWidth < 600;

  /// Check if device is tablet (600 <= width < 900)
  bool get isTablet => screenWidth >= 600 && screenWidth < 900;

  /// Check if device is desktop (width >= 900)
  bool get isDesktop => screenWidth >= 900;

  /// Get responsive padding based on screen size
  EdgeInsets get responsivePadding {
    if (isMobile) {
      return const EdgeInsets.all(16);
    } else if (isTablet) {
      return const EdgeInsets.all(24);
    } else {
      return const EdgeInsets.all(32);
    }
  }

  /// Get responsive horizontal padding
  EdgeInsets get responsiveHorizontalPadding {
    if (isMobile) {
      return const EdgeInsets.symmetric(horizontal: 16);
    } else if (isTablet) {
      return const EdgeInsets.symmetric(horizontal: 24);
    } else {
      return const EdgeInsets.symmetric(horizontal: 32);
    }
  }

  /// Get responsive card width (for centering content on large screens)
  double get maxContentWidth {
    if (isMobile) {
      return screenWidth;
    } else if (isTablet) {
      return 600;
    } else {
      return 800;
    }
  }

  /// Get responsive grid cross axis count
  int get gridCrossAxisCount {
    if (isMobile) {
      return 2;
    } else if (isTablet) {
      return 3;
    } else {
      return 4;
    }
  }

  /// Get responsive font size multiplier
  double get fontSizeMultiplier {
    if (isMobile) {
      return 1.0;
    } else if (isTablet) {
      return 1.1;
    } else {
      return 1.2;
    }
  }

  /// Get responsive spacing
  double get spacing {
    if (isMobile) {
      return 8;
    } else if (isTablet) {
      return 12;
    } else {
      return 16;
    }
  }

  /// Get responsive card elevation
  double get cardElevation {
    if (isMobile) {
      return 2;
    } else {
      return 4;
    }
  }
}
