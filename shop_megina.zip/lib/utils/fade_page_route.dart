import 'package:flutter/material.dart';

/// FadePageRoute provides a custom page route with fade transition animation
/// for smooth page navigation throughout the application.
class FadePageRoute<T> extends PageRouteBuilder<T> {
  final Widget page;
  final Duration duration;

  FadePageRoute({
    required this.page,
    this.duration = const Duration(milliseconds: 300),
    RouteSettings? settings,
  }) : super(
          pageBuilder: (context, animation, secondaryAnimation) => page,
          transitionDuration: duration,
          reverseTransitionDuration: duration,
          settings: settings,
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            // Fade transition
            return FadeTransition(opacity: animation, child: child);
          },
        );
}

/// Helper class to create fade page routes for navigation
class FadePageRouteHelper {
  /// Create a fade page route for the given widget
  static Route<T> createRoute<T>(Widget page) {
    return FadePageRoute<T>(page: page);
  }

  /// Navigate to a page with fade transition
  static Future<T?> navigateTo<T>(BuildContext context, Widget page) {
    return Navigator.push<T>(context, FadePageRoute<T>(page: page));
  }

  /// Replace current page with fade transition
  static Future<T?> replaceTo<T>(BuildContext context, Widget page) {
    return Navigator.pushReplacement<T, void>(
      context,
      FadePageRoute<T>(page: page),
    );
  }
}
