import '../models/user.dart';
import '../models/product.dart';
import '../models/cart_item.dart';
import '../models/transaction.dart';
import '../models/notification_item.dart';

class DummyDataProvider {
  static final DummyDataProvider _instance = DummyDataProvider._internal();
  factory DummyDataProvider() => _instance;
  DummyDataProvider._internal() {
    _initializeTransactions();
  }

  // Dummy users
  final List<User> users = [
    User(
      id: '1',
      name: 'Gyna ',
      email: 'megina@.com',
      role: 'seller',
      profileImage: 'https://i.pravatar.cc/150?img=1',
    ),
    User(
      id: '2',
      name: 'NehaBuyer',
      email: 'neha@buyer.com',
      role: 'buyer',
      profileImage: 'https://i.pravatar.cc/150?img=2',
    ),
    User(
      id: '3',
      name: 'Budi Seller',
      email: 'budi@seller.com',
      role: 'seller',
      profileImage: 'https://i.pravatar.cc/150?img=3',
    ),
    User(
      id: '4',
      name: 'Rina Buyer',
      email: 'rina@buyer.com',
      role: 'buyer',
      profileImage: 'https://i.pravatar.cc/150?img=4',
    ),
  ];

  // Dummy products
  final List<Product> products = [
    Product(
      id: '1',
      name: 'Laptop Gaming ROG',
      description:
          'Laptop gaming dengan spesifikasi tinggi, RAM 16GB, SSD 512GB',
      price: 15000000,
      stock: 5,
      imageUrl:
          'https://dlcdnwebimgs.asus.com/gain/269FECB7-F9EC-482E-BD97-5C7BD2C286A0/w185/fwebp',
      category: 'Electronics',
      sellerId: '1',
    ),
    Product(
      id: '2',
      name: 'Smartphone Samsung Galaxy',
      description: 'Smartphone flagship dengan kamera 108MP dan layar AMOLED',
      price: 8000000,
      stock: 10,
      imageUrl:
          'https://images.samsung.com/is/image/samsung/p6pim/id/feature/166449577/id-feature-slimmer--lighter-and-ready-to-impress-549079978?',
      category: 'Electronics',
      sellerId: '1',
    ),
    Product(
      id: '3',
      name: 'Sepatu Nike Air Max',
      description:
          'Sepatu olahraga nyaman untuk lari dan aktivitas sehari-hari',
      price: 1500000,
      stock: 20,
      imageUrl:
          'https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcTOjl95MoewHGXV8dMEIBz7CBd2dizEZgtQ6nuAufAdAAJ7ksXi',
      category: 'Fashion',
      sellerId: '3',
    ),
    Product(
      id: '4',
      name: 'Tas Ransel Eiger',
      description: 'Tas ransel outdoor dengan kapasitas besar dan tahan air',
      price: 500000,
      stock: 15,
      imageUrl:
          'https://d1yutv2xslo29o.cloudfront.net/product/variant/photo/3d71d82a-8d03-45d7-83ed-bdda1e02ea96.jpg',
      category: 'Fashion',
      sellerId: '3',
    ),
    Product(
      id: '5',
      name: 'Kamera DSLR Canon',
      description: 'Kamera DSLR profesional dengan sensor full frame',
      price: 12000000,
      stock: 3,
      imageUrl:
          'https://www.bhinneka.com/blog/wp-content/uploads/2021/07/Canon-EOS-7D.jpg',
      category: 'Electronics',
      sellerId: '1',
    ),
    Product(
      id: '6',
      name: 'Jam Tangan Casio',
      description: 'Jam tangan digital dengan fitur stopwatch dan alarm',
      price: 800000,
      stock: 25,
      imageUrl:
          'https://www.casio.com/content/dam/casio/product-info/locales/id/id/timepiece/product/watch/A/A1/A15/a158wem-3/assets/A158WEM-3.png.transform/product-panel/image.png',
      category: 'Fashion',
      sellerId: '3',
    ),
    Product(
      id: '7',
      name: 'Headphone Sony WH-1000XM4',
      description: 'Headphone noise cancelling dengan kualitas suara premium',
      price: 4500000,
      stock: 8,
      imageUrl:
          'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcTInWEGqkYPAS9sujHeSL4X921nzUYrnEZ6CnKud_GNYIraVO720nVFHQGhAr7flipGfmSAQp4ecMz1J1gHZWyp6Xy6JeXjHeCZ19oGl5snWN1Fr9EUEJzHutnT',
      category: 'Electronics',
      sellerId: '1',
    ),
    Product(
      id: '8',
      name: 'Jaket Denim Levis',
      description: 'Jaket denim klasik dengan bahan berkualitas tinggi',
      price: 1200000,
      stock: 12,
      imageUrl:
          'https://levi.co.id/cdn/shop/files/MT_72334-0322_EAS_PS_LD_FV_3558X2000.progressive.jpg?v=1749571807',
      category: 'Fashion',
      sellerId: '3',
    ),
  ];

  // Dummy transactions - initialized in constructor
  late final List<Transaction> transactions;

  // Dummy notifications
  final List<NotificationItem> notifications = [
    NotificationItem(
      id: '1',
      title: 'Pesanan Berhasil',
      message: 'Pesanan Anda telah berhasil diproses',
      timestamp: DateTime.now().subtract(const Duration(hours: 2)),
      isRead: false,
      type: 'order',
    ),
    NotificationItem(
      id: '2',
      title: 'Produk Baru',
      message: 'Ada produk baru yang mungkin Anda suka',
      timestamp: DateTime.now().subtract(const Duration(days: 1)),
      isRead: true,
      type: 'promotion',
    ),
    NotificationItem(
      id: '3',
      title: 'Pembayaran Diterima',
      message: 'Pembayaran untuk pesanan #12345 telah diterima',
      timestamp: DateTime.now().subtract(const Duration(days: 2)),
      isRead: true,
      type: 'payment',
    ),
    NotificationItem(
      id: '4',
      title: 'Produk Terjual',
      message: 'Produk Laptop Gaming ROG Anda telah terjual',
      timestamp: DateTime.now().subtract(const Duration(hours: 5)),
      isRead: false,
      type: 'sale',
    ),
  ];

  // Cart (in-memory)
  final List<CartItem> cart = [];

  // Initialize transactions with proper items
  void _initializeTransactions() {
    transactions = [
      Transaction(
        id: '1',
        userId: '2', // Siti Buyer
        items: [
          CartItem(product: products[0], quantity: 1), // Laptop Gaming ROG
          CartItem(product: products[1], quantity: 1), // Smartphone Samsung
        ],
        totalAmount: 23000000,
        paymentMethod: 'Credit Card',
        date: DateTime.now().subtract(const Duration(days: 5)),
        status: 'completed',
      ),
      Transaction(
        id: '2',
        userId: '4', // Rina Buyer
        items: [
          CartItem(product: products[2], quantity: 1), // Sepatu Nike
          CartItem(product: products[3], quantity: 1), // Tas Ransel
        ],
        totalAmount: 2000000,
        paymentMethod: 'Bank Transfer',
        date: DateTime.now().subtract(const Duration(days: 3)),
        status: 'completed',
      ),
      Transaction(
        id: '3',
        userId: '2', // Siti Buyer
        items: [
          CartItem(product: products[4], quantity: 1), // Headphone Sony
        ],
        totalAmount: 4500000,
        paymentMethod: 'E-Wallet',
        date: DateTime.now().subtract(const Duration(days: 1)),
        status: 'completed',
      ),
      Transaction(
        id: '4',
        userId: '4', // Rina Buyer
        items: [
          CartItem(product: products[4], quantity: 1), // Kamera DSLR
        ],
        totalAmount: 12000000,
        paymentMethod: 'Credit Card',
        date: DateTime.now().subtract(const Duration(hours: 12)),
        status: 'completed',
      ),
    ];
  }

  // Helper methods
  User? getUserByEmail(String email) {
    try {
      return users.firstWhere((user) => user.email == email);
    } catch (e) {
      return null;
    }
  }

  List<Product> getProductsBySeller(String sellerId) {
    return products.where((product) => product.sellerId == sellerId).toList();
  }

  List<Product> getProductsByCategory(String category) {
    return products.where((product) => product.category == category).toList();
  }

  List<Product> searchProducts(String query) {
    final lowerQuery = query.toLowerCase();
    return products.where((product) {
      return product.name.toLowerCase().contains(lowerQuery) ||
          product.description.toLowerCase().contains(lowerQuery);
    }).toList();
  }

  // Cart management methods
  void addToCart(Product product) {
    final existingItemIndex = cart.indexWhere(
      (item) => item.product.id == product.id,
    );

    if (existingItemIndex >= 0) {
      cart[existingItemIndex].quantity++;
    } else {
      cart.add(CartItem(product: product, quantity: 1));
    }
  }

  void removeFromCart(String productId) {
    cart.removeWhere((item) => item.product.id == productId);
  }

  void updateCartQuantity(String productId, int quantity) {
    final itemIndex = cart.indexWhere((item) => item.product.id == productId);

    if (itemIndex >= 0) {
      if (quantity <= 0) {
        cart.removeAt(itemIndex);
      } else {
        cart[itemIndex].quantity = quantity;
      }
    }
  }

  double getCartTotal() {
    return cart.fold(0.0, (sum, item) => sum + item.totalPrice);
  }

  // Product management methods
  void updateProduct(Product updatedProduct) {
    final index = products.indexWhere((p) => p.id == updatedProduct.id);
    if (index >= 0) {
      products[index] = updatedProduct;
    }
  }

  void deleteProduct(String productId) {
    products.removeWhere((p) => p.id == productId);
    // Also remove from cart if exists
    cart.removeWhere((item) => item.product.id == productId);
  }

  void addProduct(Product product) {
    products.add(product);
  }

  // Create new transaction
  void createTransaction({
    required String userId,
    required List<CartItem> items,
    required double totalAmount,
    required String paymentMethod,
  }) {
    final newTransaction = Transaction(
      id: (transactions.length + 1).toString(),
      userId: userId,
      items: items,
      totalAmount: totalAmount,
      paymentMethod: paymentMethod,
      date: DateTime.now(),
      status: 'completed',
    );
    transactions.add(newTransaction);
  }

  // Transaction filtering methods
  List<Transaction> getTransactionsByBuyer(String buyerId) {
    return transactions
        .where((transaction) => transaction.userId == buyerId)
        .toList();
  }

  List<Transaction> getTransactionsBySeller(String sellerId) {
    return transactions.where((transaction) {
      // Check if any item in the transaction is from this seller
      return transaction.items.any((item) => item.product.sellerId == sellerId);
    }).toList();
  }
}
