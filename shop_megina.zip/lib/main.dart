import 'package:flutter/material.dart';
import 'package:online_shop/routes/app_routes.dart';
import 'package:online_shop/themes/app_theme.dart';
import 'package:online_shop/screens/intro_screen.dart';
import 'package:online_shop/screens/login_screen.dart';
import 'package:online_shop/screens/register_screen.dart';
import 'package:online_shop/screens/seller_dashboard_screen.dart';
import 'package:online_shop/screens/buyer_dashboard_screen.dart';
import 'package:online_shop/screens/product_detail_screen.dart';
import 'package:online_shop/screens/add_product_screen.dart';
import 'package:online_shop/screens/edit_product_screen.dart';
import 'package:online_shop/screens/product_list_screen.dart';
import 'package:online_shop/screens/cart_screen.dart';
import 'package:online_shop/screens/checkout_screen.dart';
import 'package:online_shop/screens/profile_screen.dart';
import 'package:online_shop/screens/settings_screen.dart';
import 'package:online_shop/screens/transaction_history_screen.dart';
import 'package:online_shop/screens/transaction_detail_screen.dart';
import 'package:online_shop/screens/notification_screen.dart';
import 'package:online_shop/utils/fade_page_route.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Online Shop',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      // Set initial route to intro screen
      initialRoute: AppRoutes.buyerDashboard,
      // Use custom route generator for fade transitions
      onGenerateRoute: (settings) {
        Widget page;

        switch (settings.name) {
          case AppRoutes.intro:
            page = const IntroScreen();
            break;
          case AppRoutes.login:
            page = const LoginScreen();
            break;
          case AppRoutes.register:
            page = const RegisterScreen();
            break;
          case AppRoutes.sellerDashboard:
            page = const SellerDashboardScreen();
            break;
          case AppRoutes.buyerDashboard:
            page = const BuyerDashboardScreen();
            break;
          case AppRoutes.productDetail:
            page = const ProductDetailScreen();
            break;
          case AppRoutes.addProduct:
            page = const AddProductScreen();
            break;
          case AppRoutes.editProduct:
            page = const EditProductScreen();
            break;
          case AppRoutes.productList:
            page = const ProductListScreen();
            break;
          case AppRoutes.cart:
            page = const CartScreen();
            break;
          case AppRoutes.checkout:
            page = const CheckoutScreen();
            break;
          case AppRoutes.profile:
            page = const ProfileScreen();
            break;
          case AppRoutes.settings:
            page = const SettingsScreen();
            break;
          case AppRoutes.transactionHistory:
            page = const TransactionHistoryScreen();
            break;
          case AppRoutes.transactionDetail:
            page = const TransactionDetailScreen();
            break;
          case AppRoutes.notifications:
            page = const NotificationScreen();
            break;
          default:
            page = const IntroScreen();
        }

        return FadePageRoute(page: page, settings: settings);
      },
    );
  }
}
