import 'package:flutter/material.dart';
import 'package:online_shop/models/product.dart';
import 'package:online_shop/models/transaction.dart';

/// RouteArguments classes for passing data between screens via navigation

/// Arguments for ProductDetailScreen
class ProductDetailArguments {
  final Product product;
  final String userRole; // 'seller' or 'buyer'

  ProductDetailArguments({required this.product, required this.userRole});
}

/// Arguments for EditProductScreen
class EditProductArguments {
  final Product product;

  EditProductArguments({required this.product});
}

/// Arguments for TransactionDetailScreen
class TransactionDetailArguments {
  final Transaction transaction;

  TransactionDetailArguments({required this.transaction});
}

/// Helper class for navigation with arguments
class NavigationHelper {
  /// Navigate to product detail screen
  static Future<void> navigateToProductDetail(
    context, {
    required Product product,
    required String userRole,
  }) {
    return Navigator.pushNamed(
      context,
      '/product-detail',
      arguments: ProductDetailArguments(product: product, userRole: userRole),
    );
  }

  /// Navigate to edit product screen
  static Future<void> navigateToEditProduct(
    context, {
    required Product product,
  }) {
    return Navigator.pushNamed(
      context,
      '/edit-product',
      arguments: EditProductArguments(product: product),
    );
  }

  /// Navigate to transaction detail screen
  static Future<void> navigateToTransactionDetail(
    context, {
    required Transaction transaction,
  }) {
    return Navigator.pushNamed(
      context,
      '/transaction-detail',
      arguments: TransactionDetailArguments(transaction: transaction),
    );
  }
}
