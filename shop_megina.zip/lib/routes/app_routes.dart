/// AppRoutes defines all named route constants for the application.
/// This provides a centralized location for managing navigation routes.
class AppRoutes {
  // Private constructor to prevent instantiation
  AppRoutes._();

  // Authentication routes
  static const String intro = '/';
  static const String login = '/login';
  static const String register = '/register';

  // Dashboard routes
  static const String sellerDashboard = '/seller-dashboard';
  static const String buyerDashboard = '/buyer-dashboard';

  // Product routes
  static const String productDetail = '/product-detail';
  static const String addProduct = '/add-product';
  static const String editProduct = '/edit-product';
  static const String productList = '/product-list';

  // Cart and checkout routes
  static const String cart = '/cart';
  static const String checkout = '/checkout';

  // Profile and settings routes
  static const String profile = '/profile';
  static const String settings = '/settings';

  // Transaction routes
  static const String transactionHistory = '/transaction-history';
  static const String transactionDetail = '/transaction-detail';

  // Notification routes
  static const String notifications = '/notifications';
}
