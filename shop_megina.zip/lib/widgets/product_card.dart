import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/product.dart';
import '../themes/app_colors.dart';

/// ProductCard is a reusable widget that displays product information
/// with action buttons and tap animations.
class ProductCard extends StatefulWidget {
  final Product product;
  final VoidCallback onTap;
  final bool showActions;
  final VoidCallback? onAddToCart;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  const ProductCard({
    super.key,
    required this.product,
    required this.onTap,
    this.showActions = false,
    this.onAddToCart,
    this.onEdit,
    this.onDelete,
  });

  @override
  State<ProductCard> createState() => _ProductCardState();
}

class _ProductCardState extends State<ProductCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  bool _isHovered = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 150),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 0.97,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _handleTapDown(TapDownDetails details) {
    _controller.forward();
  }

  void _handleTapUp(TapUpDetails details) {
    _controller.reverse();
  }

  void _handleTapCancel() {
    _controller.reverse();
  }

  /// Format harga ke format Rupiah dengan pemisah ribuan
  String _formatPrice(double price) {
    return price.toStringAsFixed(0).replaceAllMapped(
          RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
          (Match m) => '${m[1]}.',
        );
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: _scaleAnimation,
      child: MouseRegion(
        onEnter: (_) => setState(() => _isHovered = true),
        onExit: (_) => setState(() => _isHovered = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          decoration: BoxDecoration(
            color: AppColors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: _isHovered
                    ? AppColors.softBlue.withValues(alpha: 0.2)
                    : Colors.black.withValues(alpha: 0.08),
                blurRadius: _isHovered ? 12 : 8,
                offset: Offset(0, _isHovered ? 4 : 2),
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: widget.onTap,
              onTapDown: _handleTapDown,
              onTapUp: _handleTapUp,
              onTapCancel: _handleTapCancel,
              borderRadius: BorderRadius.circular(16),
              child: LayoutBuilder(
                builder: (context, constraints) {
                  // Hitung ukuran yang tersedia
                  final cardHeight = constraints.maxHeight;
                  final cardWidth = constraints.maxWidth;
                  
                  // Image mengambil 1:1 aspect ratio (square)
                  final imageHeight = cardWidth;
                  
                  // Sisa ruang untuk konten
                  final contentHeight = cardHeight - imageHeight;
                  
                  // Tentukan apakah ruang cukup untuk menampilkan semua elemen
                  final isCompact = contentHeight < 120;
                  
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Product Image
                      ClipRRect(
                        borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(16),
                        ),
                        child: AspectRatio(
                          aspectRatio: 1.0,
                          child: CachedNetworkImage(
                            imageUrl: widget.product.imageUrl,
                            fit: BoxFit.cover,
                            placeholder: (context, url) => Container(
                              color: AppColors.softGrey,
                              child: const Center(
                                child: CircularProgressIndicator(strokeWidth: 2),
                              ),
                            ),
                            errorWidget: (context, url, error) => Container(
                              color: AppColors.softGrey,
                              child: const Icon(
                                Icons.image_not_supported,
                                size: 48,
                                color: AppColors.textSecondary,
                              ),
                            ),
                          ),
                        ),
                      ),
                      // Product Info - Menggunakan Expanded untuk mengambil sisa ruang
                      Expanded(
                        child: Padding(
                          padding: EdgeInsets.all(isCompact ? 6 : 8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              // Nama Produk
                              Flexible(
                                child: Text(
                                  widget.product.name,
                                  style: TextStyle(
                                    fontSize: isCompact ? 12 : 14,
                                    fontWeight: FontWeight.w600,
                                    color: AppColors.textPrimary,
                                    height: 1.2,
                                  ),
                                  maxLines: isCompact ? 1 : 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              SizedBox(height: isCompact ? 2 : 4),
                              // Harga dengan format Rupiah
                              Text(
                                'Rp ${_formatPrice(widget.product.price)}',
                                style: TextStyle(
                                  fontSize: isCompact ? 14 : 16,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.softBlue,
                                  height: 1.1,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              SizedBox(height: isCompact ? 1 : 2),
                              // Stock
                              Text(
                                'Stock: ${widget.product.stock}',
                                style: TextStyle(
                                  fontSize: isCompact ? 10 : 11,
                                  color: AppColors.textSecondary,
                                  height: 1.1,
                                ),
                              ),
                              // Action Buttons
                              if (widget.showActions) ...[
                                const Spacer(),
                                Padding(
                                  padding: EdgeInsets.only(top: isCompact ? 2 : 4),
                                  child: SizedBox(
                                    height: isCompact ? 28 : 32,
                                    child: Row(
                                      children: [
                                        if (widget.onAddToCart != null)
                                          Expanded(
                                            flex: 3,
                                            child: ElevatedButton(
                                              onPressed: widget.onAddToCart,
                                              style: ElevatedButton.styleFrom(
                                                padding: EdgeInsets.symmetric(
                                                  horizontal: isCompact ? 4 : 6,
                                                ),
                                                minimumSize: Size.zero,
                                                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                              ),
                                              child: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Icon(
                                                    Icons.add_shopping_cart,
                                                    size: isCompact ? 12 : 14,
                                                  ),
                                                  SizedBox(width: isCompact ? 1 : 2),
                                                  Flexible(
                                                    child: Text(
                                                      'Add',
                                                      style: TextStyle(
                                                        fontSize: isCompact ? 9 : 10,
                                                      ),
                                                      overflow: TextOverflow.ellipsis,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        if (widget.onEdit != null) ...[
                                          const SizedBox(width: 4),
                                          SizedBox(
                                            width: isCompact ? 28 : 32,
                                            child: IconButton(
                                              onPressed: widget.onEdit,
                                              icon: const Icon(Icons.edit),
                                              color: AppColors.softBlue,
                                              iconSize: isCompact ? 14 : 16,
                                              padding: EdgeInsets.zero,
                                              tooltip: 'Edit',
                                              constraints: const BoxConstraints(),
                                            ),
                                          ),
                                        ],
                                        if (widget.onDelete != null) ...[
                                          const SizedBox(width: 4),
                                          SizedBox(
                                            width: isCompact ? 28 : 32,
                                            child: IconButton(
                                              onPressed: widget.onDelete,
                                              icon: const Icon(Icons.delete),
                                              color: AppColors.error,
                                              iconSize: isCompact ? 14 : 16,
                                              padding: EdgeInsets.zero,
                                              tooltip: 'Delete',
                                              constraints: const BoxConstraints(),
                                            ),
                                          ),
                                        ],
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}