import 'package:flutter/material.dart';

/// AppColors defines the color palette for the application
/// with soft, modern colors for a minimalist design.
class AppColors {
  // Primary colors
  static const Color softBlue = Color(0xFF6C8FF8);
  static const Color softPurple = Color(0xFFA084E8);
  static const Color softGrey = Color(0xFFF5F7FA);

  // Additional colors for UI elements
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF000000);
  static const Color textPrimary = Color(0xFF2D3748);
  static const Color textSecondary = Color(0xFF718096);
  static const Color error = Color(0xFFE53E3E);
  static const Color success = Color(0xFF38A169);
  static const Color warning = Color(0xFFED8936);

  // Gradient colors
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [softBlue, softPurple],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // Prevent instantiation
  AppColors._();
}
