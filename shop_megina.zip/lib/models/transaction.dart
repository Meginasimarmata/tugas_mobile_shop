import 'cart_item.dart';

class Transaction {
  final String id;
  final String userId;
  final List<CartItem> items;
  final double totalAmount;
  final String paymentMethod;
  final DateTime date;
  final String status;

  Transaction({
    required this.id,
    required this.userId,
    required this.items,
    required this.totalAmount,
    required this.paymentMethod,
    required this.date,
    required this.status,
  });
}
