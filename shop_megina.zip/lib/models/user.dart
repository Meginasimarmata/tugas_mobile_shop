class User {
  final String id;
  final String name;
  final String email;
  final String role; // 'seller' or 'buyer'
  final String? profileImage;

  User({
    required this.id,
    required this.name,
    required this.email,
    required this.role,
    this.profileImage,
  });
}
