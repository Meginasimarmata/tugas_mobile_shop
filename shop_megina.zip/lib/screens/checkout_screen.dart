import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../data/dummy_data_provider.dart';
import '../models/cart_item.dart';
import '../themes/app_colors.dart';
import '../widgets/custom_button.dart';
import '../routes/app_routes.dart';

/// CheckoutScreen displays the order summary with products, quantities, prices,
/// payment method selection, and allows users to complete their purchase.
class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final DummyDataProvider _dataProvider = DummyDataProvider();
  String _selectedPaymentMethod = 'Credit Card';

  final List<String> _paymentMethods = [
    'Credit Card',
    'Bank Transfer',
    'E-Wallet',
    'Cash on Delivery',
  ];

  @override
  Widget build(BuildContext context) {
    final cartItems = _dataProvider.cart;
    final cartTotal = _dataProvider.getCartTotal();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Checkout'),
        backgroundColor: AppColors.white,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.softGrey, height: 1),
        ),
      ),
      body: Column(
        children: [
          // Scrollable content
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Order summary section
                  _buildSectionTitle('Ringkasan Pesanan'),
                  const SizedBox(height: 12),
                  _buildOrderSummary(cartItems),
                  const SizedBox(height: 24),

                  // Payment method section
                  _buildSectionTitle('Metode Pembayaran'),
                  const SizedBox(height: 12),
                  _buildPaymentMethodSelection(),
                ],
              ),
            ),
          ),

          // Bottom section with total and pay button
          _buildBottomSection(cartTotal),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.bold,
        color: AppColors.textPrimary,
      ),
    );
  }

  Widget _buildOrderSummary(List<CartItem> cartItems) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // List of cart items
            ...cartItems.asMap().entries.map((entry) {
              final index = entry.key;
              final cartItem = entry.value;
              return Column(
                children: [
                  _buildOrderItem(cartItem),
                  if (index < cartItems.length - 1)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Divider(height: 1),
                    ),
                ],
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildOrderItem(CartItem cartItem) {
    final product = cartItem.product;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Product image
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: CachedNetworkImage(
            imageUrl: product.imageUrl,
            width: 60,
            height: 60,
            fit: BoxFit.cover,
            placeholder: (context, url) => Container(
              width: 60,
              height: 60,
              color: AppColors.softGrey,
              child: const Center(
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
            ),
            errorWidget: (context, url, error) => Container(
              width: 60,
              height: 60,
              color: AppColors.softGrey,
              child: const Icon(Icons.image_not_supported, size: 20),
            ),
          ),
        ),
        const SizedBox(width: 12),

        // Product details
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Product name
              Text(
                product.name,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textPrimary,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),

              // Quantity
              Text(
                '${cartItem.quantity}x',
                style: const TextStyle(
                  fontSize: 13,
                  color: AppColors.textSecondary,
                ),
              ),
              const SizedBox(height: 4),

              // Price
              Text(
                'Rp ${_formatPrice(product.price)}',
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: AppColors.softBlue,
                ),
              ),
            ],
          ),
        ),

        // Item total
        Text(
          'Rp ${_formatPrice(cartItem.totalPrice)}',
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: AppColors.textPrimary,
          ),
        ),
      ],
    );
  }

  Widget _buildPaymentMethodSelection() {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      child: Column(
        children: _paymentMethods.asMap().entries.map((entry) {
          final index = entry.key;
          final method = entry.value;
          final isSelected = _selectedPaymentMethod == method;

          return Column(
            children: [
              InkWell(
                onTap: () {
                  setState(() {
                    _selectedPaymentMethod = method;
                  });
                },
                borderRadius: BorderRadius.vertical(
                  top: index == 0 ? const Radius.circular(12) : Radius.zero,
                  bottom: index == _paymentMethods.length - 1
                      ? const Radius.circular(12)
                      : Radius.zero,
                ),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? AppColors.softBlue.withValues(alpha: 0.1)
                        : Colors.transparent,
                    borderRadius: BorderRadius.vertical(
                      top: index == 0 ? const Radius.circular(12) : Radius.zero,
                      bottom: index == _paymentMethods.length - 1
                          ? const Radius.circular(12)
                          : Radius.zero,
                    ),
                  ),
                  child: Row(
                    children: [
                      // Radio button
                      Container(
                        width: 20,
                        height: 20,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: isSelected
                                ? AppColors.softBlue
                                : AppColors.textSecondary,
                            width: 2,
                          ),
                        ),
                        child: isSelected
                            ? Center(
                                child: Container(
                                  width: 10,
                                  height: 10,
                                  decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: AppColors.softBlue,
                                  ),
                                ),
                              )
                            : null,
                      ),
                      const SizedBox(width: 12),

                      // Payment method icon
                      Icon(
                        _getPaymentMethodIcon(method),
                        color: isSelected
                            ? AppColors.softBlue
                            : AppColors.textSecondary,
                        size: 24,
                      ),
                      const SizedBox(width: 12),

                      // Payment method name
                      Expanded(
                        child: Text(
                          method,
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: isSelected
                                ? FontWeight.w600
                                : FontWeight.w500,
                            color: isSelected
                                ? AppColors.softBlue
                                : AppColors.textPrimary,
                          ),
                        ),
                      ),

                      // Checkmark for selected
                      if (isSelected)
                        const Icon(
                          Icons.check_circle,
                          color: AppColors.softBlue,
                          size: 20,
                        ),
                    ],
                  ),
                ),
              ),
              if (index < _paymentMethods.length - 1)
                const Divider(height: 1, indent: 16, endIndent: 16),
            ],
          );
        }).toList(),
      ),
    );
  }

  Widget _buildBottomSection(double cartTotal) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Total price row
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Total Pembayaran',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textPrimary,
                  ),
                ),
                Text(
                  'Rp ${_formatPrice(cartTotal)}',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: AppColors.softBlue,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Pay button
            CustomButton(
              text: 'Bayar Sekarang',
              onPressed: _handlePayment,
              width: double.infinity,
            ),
          ],
        ),
      ),
    );
  }

  IconData _getPaymentMethodIcon(String method) {
    switch (method) {
      case 'Credit Card':
        return Icons.credit_card;
      case 'Bank Transfer':
        return Icons.account_balance;
      case 'E-Wallet':
        return Icons.account_balance_wallet;
      case 'Cash on Delivery':
        return Icons.local_shipping;
      default:
        return Icons.payment;
    }
  }

  void _handlePayment() {
    final cartItems = _dataProvider.cart;
    final cartTotal = _dataProvider.getCartTotal();

    // Create new transaction
    _dataProvider.createTransaction(
      userId: '2', // Default buyer (Siti Buyer)
      items: List.from(cartItems), // Copy cart items
      totalAmount: cartTotal,
      paymentMethod: _selectedPaymentMethod,
    );

    // Show success dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Success icon
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: AppColors.success.withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.check_circle,
                color: AppColors.success,
                size: 50,
              ),
            ),
            const SizedBox(height: 20),

            // Success message
            const Text(
              'Pembayaran Berhasil!',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: AppColors.textPrimary,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),

            const Text(
              'Pesanan Anda sedang diproses',
              style: TextStyle(fontSize: 14, color: AppColors.textSecondary),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          CustomButton(
            text: 'Lihat Riwayat Transaksi',
            onPressed: () {
              // Clear cart after creating transaction
              _dataProvider.cart.clear();

              // Close dialog
              Navigator.pop(context);

              // Navigate to transaction history
              Navigator.pushNamed(
                context,
                AppRoutes.transactionHistory,
              );
            },
            width: double.infinity,
          ),
        ],
      ),
    );
  }

  String _formatPrice(double price) {
    return price
        .toStringAsFixed(0)
        .replaceAllMapped(
          RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
          (Match m) => '${m[1]}.',
        );
  }
}
