import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../widgets/product_card.dart';
import '../widgets/shimmer_loading.dart';
import '../widgets/empty_state.dart';
import '../data/dummy_data_provider.dart';
import '../models/product.dart';
import '../themes/app_colors.dart';
import '../routes/route_arguments.dart';
import '../utils/responsive_helper.dart';

/// ProductListScreen displays all available products in a grid/list layout
/// with shimmer loading effect and empty state handling.
class ProductListScreen extends StatefulWidget {
  const ProductListScreen({super.key});

  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  final DummyDataProvider _dataProvider = DummyDataProvider();
  bool _isLoading = true;
  bool _isGridView = true;

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    // Simulate loading delay
    await Future.delayed(const Duration(seconds: 1));
    if (mounted) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _navigateToProductDetail(Product product) {
    NavigationHelper.navigateToProductDetail(
      context,
      product: product,
      userRole: 'buyer', // Default to buyer for product list
    );
  }

  void _toggleView() {
    setState(() {
      _isGridView = !_isGridView;
    });
  }

  String _formatPrice(double price) {
    return price
        .toStringAsFixed(0)
        .replaceAllMapped(
          RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
          (Match m) => '${m[1]}.',
        );
  }

  // Fungsi untuk mendapatkan childAspectRatio yang dinamis berdasarkan ukuran layar
  double _getChildAspectRatio(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    
    // Untuk layar kecil (mobile), gunakan aspect ratio yang lebih besar
    if (width < 600) {
      return 0.75; // Lebih tinggi untuk mobile
    }
    // Untuk tablet
    else if (width < 900) {
      return 0.72;
    }
    // Untuk desktop
    else {
      return 0.70;
    }
  }

  @override
  Widget build(BuildContext context) {
    final products = _dataProvider.products;

    return Scaffold(
      backgroundColor: AppColors.softGrey,
      appBar: AppBar(
        backgroundColor: AppColors.white,
        elevation: 0,
       
        title: const Text(
          'All Products',
          style: TextStyle(
            color: AppColors.textPrimary,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(
              _isGridView ? Icons.view_list : Icons.grid_view,
              color: AppColors.textPrimary,
            ),
            onPressed: _toggleView,
          ),
        ],
      ),
      body: _isLoading
          ? _buildShimmerLoading()
          : products.isEmpty
              ? _buildEmptyState()
              : _buildProductList(products),
    );
  }

  Widget _buildShimmerLoading() {
    final responsive = ResponsiveHelper(context);
    return Padding(
      padding: responsive.responsivePadding,
      child: _isGridView
          ? GridView.builder(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: responsive.gridCrossAxisCount,
                childAspectRatio: _getChildAspectRatio(context),
                crossAxisSpacing: responsive.spacing * 2,
                mainAxisSpacing: responsive.spacing * 2,
              ),
              itemCount: 6,
              itemBuilder: (context, index) {
                return const ShimmerLoading(
                  width: double.infinity,
                  height: double.infinity,
                  borderRadius: BorderRadius.all(Radius.circular(16)),
                );
              },
            )
          : ListView.builder(
              itemCount: 6,
              itemBuilder: (context, index) {
                return Padding(
                  padding: EdgeInsets.only(bottom: responsive.spacing * 2),
                  child: const ShimmerLoading(
                    width: double.infinity,
                    height: 120,
                    borderRadius: BorderRadius.all(Radius.circular(16)),
                  ),
                );
              },
            ),
    );
  }

  Widget _buildEmptyState() {
    return EmptyState(
      icon: Icons.inventory_2_outlined,
      message: 'No products available',
      actionText: 'Go Back',
      onAction: () => Navigator.pop(context),
    );
  }

  Widget _buildProductList(List<Product> products) {
    return RefreshIndicator(
      onRefresh: () async {
        setState(() {
          _isLoading = true;
        });
        await _loadProducts();
      },
      child: _isGridView ? _buildGridView(products) : _buildListView(products),
    );
  }

  Widget _buildGridView(List<Product> products) {
    final responsive = ResponsiveHelper(context);
    return Center(
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: responsive.isDesktop ? 1200 : double.infinity,
        ),
        child: Padding(
          padding: responsive.responsivePadding,
          child: GridView.builder(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: responsive.gridCrossAxisCount,
              childAspectRatio: _getChildAspectRatio(context),
              crossAxisSpacing: responsive.spacing * 2,
              mainAxisSpacing: responsive.spacing * 2,
            ),
            itemCount: products.length,
            itemBuilder: (context, index) {
              final product = products[index];
              return ProductCard(
                product: product,
                onTap: () => _navigateToProductDetail(product),
              ).animate().fadeIn(
                    duration: const Duration(milliseconds: 300),
                    delay: Duration(milliseconds: index * 50),
                  );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildListView(List<Product> products) {
    final responsive = ResponsiveHelper(context);
    return Center(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: responsive.maxContentWidth),
        child: ListView.builder(
          padding: responsive.responsivePadding,
          itemCount: products.length,
          itemBuilder: (context, index) {
            final product = products[index];
            return Padding(
              padding: EdgeInsets.only(bottom: responsive.spacing * 2),
              child: _buildListItem(product, index),
            );
          },
        ),
      ),
    );
  }

  Widget _buildListItem(Product product, int index) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _navigateToProductDetail(product),
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                // Product Image
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.network(
                    product.imageUrl,
                    width: 100,
                    height: 100,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        width: 100,
                        height: 100,
                        color: AppColors.softGrey,
                        child: const Icon(
                          Icons.image_not_supported,
                          size: 32,
                          color: AppColors.textSecondary,
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 12),
                // Product Info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        product.name,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        product.description,
                        style: const TextStyle(
                          fontSize: 12,
                          color: AppColors.textSecondary,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Rp ${_formatPrice(product.price)}',
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: AppColors.softBlue,
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: product.stock > 0
                                  ? AppColors.softGrey
                                  : AppColors.error.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              'Stock: ${product.stock}',
                              style: TextStyle(
                                fontSize: 12,
                                color: product.stock > 0
                                    ? AppColors.textSecondary
                                    : AppColors.error,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ).animate().fadeIn(
          duration: const Duration(milliseconds: 300),
          delay: Duration(milliseconds: index * 50),
        );
  }
}