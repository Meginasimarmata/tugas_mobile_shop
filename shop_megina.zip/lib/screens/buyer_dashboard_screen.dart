import 'package:flutter/material.dart';
import '../widgets/product_card.dart';
import '../data/dummy_data_provider.dart';
import '../models/product.dart';
import '../themes/app_colors.dart';
import '../routes/app_routes.dart';
import '../routes/route_arguments.dart';
import '../utils/responsive_helper.dart';
import '../screens/cart_screen.dart';
import '../screens/profile_screen.dart';

/// BuyerDashboardScreen displays the buyer's dashboard with product browsing
/// and search features
class BuyerDashboardScreen extends StatefulWidget {
  const BuyerDashboardScreen({super.key});

  @override
  State<BuyerDashboardScreen> createState() => _BuyerDashboardScreenState();
}

class _BuyerDashboardScreenState extends State<BuyerDashboardScreen> {
  final DummyDataProvider _dataProvider = DummyDataProvider();
  final TextEditingController _searchController = TextEditingController();

  int _selectedIndex = 0;
  String _selectedCategory = 'All';
  String _searchQuery = '';
  int _cartRefreshKey = 0; // Key to force cart refresh

  // Get unique categories from products
  List<String> get _categories {
    final categories = _dataProvider.products
        .map((product) => product.category)
        .toSet()
        .toList();
    return ['All', ...categories];
  }

  // Get filtered products based on search and category
  List<Product> get _filteredProducts {
    List<Product> products = _dataProvider.products;

    // Apply category filter
    if (_selectedCategory != 'All') {
      products = _dataProvider.getProductsByCategory(_selectedCategory);
    }

    // Apply search filter
    if (_searchQuery.isNotEmpty) {
      products = products.where((product) {
        final lowerQuery = _searchQuery.toLowerCase();
        return product.name.toLowerCase().contains(lowerQuery) ||
            product.description.toLowerCase().contains(lowerQuery);
      }).toList();
    }

    return products;
  }

  // Get cart item count
  int get _cartItemCount {
    return _dataProvider.cart.length;
  }

  void _onBottomNavTap(int index) {
    setState(() {
      _selectedIndex = index;
      // Refresh cart when switching to cart tab
      if (index == 1) {
        _cartRefreshKey++;
      }
    });
  }

  void _navigateToProductDetail(Product product) async {
    await NavigationHelper.navigateToProductDetail(
      context,
      product: product,
      userRole: 'buyer',
    );
    // Refresh state after returning from product detail
    setState(() {});
  }

  void _onSearchChanged(String value) {
    setState(() {
      _searchQuery = value;
    });
  }

  void _onCategorySelected(String category) {
    setState(() {
      _selectedCategory = category;
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Widget _buildHomePage(ResponsiveHelper responsive) {
    return RefreshIndicator(
      onRefresh: () async {
        // Simulate refresh
        await Future.delayed(const Duration(seconds: 1));
        setState(() {});
      },
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: Center(
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxWidth: responsive.isDesktop ? 1200 : double.infinity,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Promotional Banner
                Container(
                  width: double.infinity,
                  margin: responsive.responsivePadding,
                  padding: EdgeInsets.all(responsive.spacing * 3),
                  decoration: BoxDecoration(
                    gradient: AppColors.primaryGradient,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.softBlue.withValues(alpha: 0.3),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Special Offer!',
                        style: TextStyle(
                          color: AppColors.white,
                          fontSize: responsive.isMobile ? 24 : 28,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: responsive.spacing),
                      Text(
                        'Get up to 50% off on selected items',
                        style: TextStyle(
                          color: AppColors.white,
                          fontSize: responsive.isMobile ? 16 : 18,
                        ),
                      ),
                      SizedBox(height: responsive.spacing * 2),
                      ElevatedButton(
                        onPressed: () async {
                          // Navigate to product list or deals
                          await Navigator.pushNamed(
                              context, AppRoutes.productList);
                          // Refresh state after returning
                          setState(() {});
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.white,
                          foregroundColor: AppColors.softBlue,
                          padding: EdgeInsets.symmetric(
                            horizontal: responsive.spacing * 3,
                            vertical: responsive.spacing * 1.5,
                          ),
                        ),
                        child: const Text('Shop Now'),
                      ),
                    ],
                  ),
                ),

                // Search Bar
                Padding(
                  padding: responsive.responsiveHorizontalPadding,
                  child: TextField(
                    controller: _searchController,
                    onChanged: _onSearchChanged,
                    decoration: InputDecoration(
                      hintText: 'Search products...',
                      prefixIcon: const Icon(Icons.search),
                      suffixIcon: _searchQuery.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.clear),
                              onPressed: () {
                                _searchController.clear();
                                _onSearchChanged('');
                              },
                            )
                          : null,
                      filled: true,
                      fillColor: AppColors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: EdgeInsets.symmetric(
                        horizontal: responsive.spacing * 2,
                        vertical: responsive.spacing * 1.5,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: responsive.spacing * 2),

                // Category Filter Buttons
                SizedBox(
                  height: 50,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    padding: responsive.responsiveHorizontalPadding,
                    itemCount: _categories.length,
                    itemBuilder: (context, index) {
                      final category = _categories[index];
                      final isSelected = category == _selectedCategory;

                      return Padding(
                        padding: EdgeInsets.only(right: responsive.spacing),
                        child: FilterChip(
                          label: Text(category),
                          selected: isSelected,
                          onSelected: (selected) {
                            _onCategorySelected(category);
                          },
                          backgroundColor: AppColors.white,
                          selectedColor: AppColors.softBlue,
                          labelStyle: TextStyle(
                            color: isSelected
                                ? AppColors.white
                                : AppColors.textPrimary,
                            fontWeight: isSelected
                                ? FontWeight.bold
                                : FontWeight.normal,
                          ),
                          padding: EdgeInsets.symmetric(
                            horizontal: responsive.spacing * 2,
                            vertical: responsive.spacing,
                          ),
                        ),
                      );
                    },
                  ),
                ),
                SizedBox(height: responsive.spacing * 2),

                // Products Section Header
                Padding(
                  padding: responsive.responsiveHorizontalPadding,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        _selectedCategory == 'All'
                            ? 'All Products'
                            : _selectedCategory,
                        style: TextStyle(
                          fontSize: responsive.isMobile ? 20 : 24,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      Text(
                        '${_filteredProducts.length} items',
                        style: TextStyle(
                          fontSize: responsive.isMobile ? 14 : 16,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: responsive.spacing * 2),

                // Products Grid
                Padding(
                  padding: responsive.responsiveHorizontalPadding,
                  child: GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: responsive.gridCrossAxisCount,
                      childAspectRatio: 0.75,
                      crossAxisSpacing: responsive.spacing * 2,
                      mainAxisSpacing: responsive.spacing * 2,
                    ),
                    itemCount: _filteredProducts.length,
                    itemBuilder: (context, index) {
                      final product = _filteredProducts[index];
                      return ProductCard(
                        product: product,
                        onTap: () => _navigateToProductDetail(product),
                      );
                    },
                  ),
                ),
                SizedBox(height: responsive.spacing * 2),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final responsive = ResponsiveHelper(context);

    // Define page titles
    const pageTitles = ['Shop', 'Cart', 'Profile'];

    return Scaffold(
      backgroundColor: AppColors.softGrey,
      appBar: AppBar(
        backgroundColor: AppColors.white,
        elevation: 0,
        automaticallyImplyLeading: false, // Remove back button
        title: Text(
          pageTitles[_selectedIndex],
          style: const TextStyle(
            color: AppColors.textPrimary,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: _selectedIndex == 0
            ? [
                IconButton(
                  icon: const Icon(Icons.notifications_outlined),
                  color: AppColors.textPrimary,
                  onPressed: () {
                    Navigator.pushNamed(context, AppRoutes.notifications);
                  },
                ),
              ]
            : null,
      ),
      body: IndexedStack(
        index: _selectedIndex,
        children: [
          _buildHomePage(responsive),
          CartScreen(key: ValueKey(_cartRefreshKey), showAppBar: false),
          const ProfileScreen(showAppBar: false),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onBottomNavTap,
        selectedItemColor: AppColors.softBlue,
        unselectedItemColor: AppColors.textSecondary,
        items: [
          const BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(
            icon: _cartItemCount > 0
                ? Badge(
                    label: Text(_cartItemCount.toString()),
                    child: const Icon(Icons.shopping_cart),
                  )
                : const Icon(Icons.shopping_cart),
            label: 'Cart',
          ),
          const BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
