import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../themes/app_colors.dart';
import '../routes/app_routes.dart';
import '../widgets/custom_button.dart';
import '../utils/responsive_helper.dart';

/// IntroScreen displays the welcome page when the application starts.
/// It shows the app logo, title, description, and a start button with fade-in animations.
class IntroScreen extends StatelessWidget {
  const IntroScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final responsive = ResponsiveHelper(context);

    return Scaffold(
      backgroundColor: AppColors.white,
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: responsive.maxContentWidth),
            child: Padding(
              padding: responsive.responsiveHorizontalPadding,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Spacer(),

                  // Logo
                  Icon(
                    Icons.shopping_bag_rounded,
                    size: responsive.isMobile ? 120 : 150,
                    color: AppColors.softBlue,
                  ).animate().fadeIn(
                    duration: const Duration(milliseconds: 800),
                    delay: const Duration(milliseconds: 200),
                  ),

                  SizedBox(height: responsive.spacing * 4),

                  // Title
                  Text(
                    'Online Shop',
                    style: Theme.of(context).textTheme.displayLarge?.copyWith(
                      color: AppColors.softBlue,
                      fontWeight: FontWeight.bold,
                      fontSize: responsive.isMobile ? 32 : 40,
                    ),
                    textAlign: TextAlign.center,
                  ).animate().fadeIn(
                    duration: const Duration(milliseconds: 800),
                    delay: const Duration(milliseconds: 400),
                  ),

                  SizedBox(height: responsive.spacing * 2),

                  // Description
                  Text(
                    'Temukan produk terbaik dari penjual terpercaya. '
                    'Belanja mudah, cepat, dan aman.',
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: AppColors.textSecondary,
                      height: 1.5,
                      fontSize: responsive.isMobile ? 16 : 18,
                    ),
                    textAlign: TextAlign.center,
                  ).animate().fadeIn(
                    duration: const Duration(milliseconds: 800),
                    delay: const Duration(milliseconds: 600),
                  ),

                  const Spacer(),

                  // Start Button
                  CustomButton(
                    text: 'Mulai',
                    onPressed: () {
                      Navigator.pushNamed(context, AppRoutes.login);
                    },
                    width: double.infinity,
                  ).animate().fadeIn(
                    duration: const Duration(milliseconds: 800),
                    delay: const Duration(milliseconds: 800),
                  ),

                  SizedBox(height: responsive.spacing * 6),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
