import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../themes/app_colors.dart';

/// SettingsScreen - Allows users to configure app preferences
/// including language, theme, and notification settings
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  // Setting values - Requirements 13.4: Display current setting values on page load
  String _selectedLanguage = 'English';
  String _selectedTheme = 'Light';
  bool _notificationsEnabled = true;
  bool _emailNotifications = true;
  bool _pushNotifications = true;

  // Available options
  final List<String> _languages = [
    'English',
    'Indonesian',
    'Spanish',
    'French',
  ];
  final List<String> _themes = ['Light', 'Dark', 'System'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Language Section
          _buildSectionTitle('Language'),
          _buildLanguageDropdown(),
          const SizedBox(height: 24),

          // Theme Section
          _buildSectionTitle('Theme'),
          _buildThemeDropdown(),
          const SizedBox(height: 24),

          // Notification Section
          _buildSectionTitle('Notifications'),
          _buildNotificationToggle(
            title: 'Enable Notifications',
            subtitle: 'Receive notifications from the app',
            value: _notificationsEnabled,
            onChanged: (value) {
              _updateSetting(() {
                _notificationsEnabled = value;
                // If disabling all notifications, disable sub-options too
                if (!value) {
                  _emailNotifications = false;
                  _pushNotifications = false;
                }
              });
            },
          ),
          if (_notificationsEnabled) ...[
            _buildNotificationToggle(
              title: 'Email Notifications',
              subtitle: 'Receive notifications via email',
              value: _emailNotifications,
              onChanged: (value) {
                _updateSetting(() {
                  _emailNotifications = value;
                });
              },
            ),
            _buildNotificationToggle(
              title: 'Push Notifications',
              subtitle: 'Receive push notifications',
              value: _pushNotifications,
              onChanged: (value) {
                _updateSetting(() {
                  _pushNotifications = value;
                });
              },
            ),
          ],
        ],
      ).animate().fadeIn(duration: 300.ms),
    );
  }

  /// Build section title widget
  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        title,
        style: Theme.of(context).textTheme.titleLarge?.copyWith(
          fontWeight: FontWeight.w600,
          color: AppColors.textPrimary,
        ),
      ),
    );
  }

  /// Build language dropdown - Requirements 13.2: Implement appropriate UI controls
  Widget _buildLanguageDropdown() {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: AppColors.softGrey, width: 1),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<String>(
            value: _selectedLanguage,
            isExpanded: true,
            icon: const Icon(Icons.arrow_drop_down, color: AppColors.softBlue),
            items: _languages.map((String language) {
              return DropdownMenuItem<String>(
                value: language,
                child: Row(
                  children: [
                    const Icon(
                      Icons.language,
                      color: AppColors.softBlue,
                      size: 20,
                    ),
                    const SizedBox(width: 12),
                    Text(
                      language,
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                  ],
                ),
              );
            }).toList(),
            onChanged: (String? newValue) {
              if (newValue != null) {
                _updateSetting(() {
                  _selectedLanguage = newValue;
                });
              }
            },
          ),
        ),
      ),
    );
  }

  /// Build theme dropdown - Requirements 13.2: Implement appropriate UI controls
  Widget _buildThemeDropdown() {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: AppColors.softGrey, width: 1),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<String>(
            value: _selectedTheme,
            isExpanded: true,
            icon: const Icon(Icons.arrow_drop_down, color: AppColors.softBlue),
            items: _themes.map((String theme) {
              IconData themeIcon;
              switch (theme) {
                case 'Light':
                  themeIcon = Icons.light_mode;
                  break;
                case 'Dark':
                  themeIcon = Icons.dark_mode;
                  break;
                case 'System':
                  themeIcon = Icons.settings_brightness;
                  break;
                default:
                  themeIcon = Icons.brightness_auto;
              }
              return DropdownMenuItem<String>(
                value: theme,
                child: Row(
                  children: [
                    Icon(themeIcon, color: AppColors.softBlue, size: 20),
                    const SizedBox(width: 12),
                    Text(theme, style: Theme.of(context).textTheme.bodyLarge),
                  ],
                ),
              );
            }).toList(),
            onChanged: (String? newValue) {
              if (newValue != null) {
                _updateSetting(() {
                  _selectedTheme = newValue;
                });
              }
            },
          ),
        ),
      ),
    );
  }

  /// Build notification toggle switch - Requirements 13.2: Implement appropriate UI controls
  Widget _buildNotificationToggle({
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: AppColors.softGrey, width: 1),
      ),
      child: SwitchListTile(
        title: Text(
          title,
          style: Theme.of(
            context,
          ).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w500),
        ),
        subtitle: Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
        value: value,
        onChanged: onChanged,
        activeTrackColor: AppColors.softBlue.withValues(alpha: 0.5),
        thumbColor: WidgetStateProperty.resolveWith<Color>((
          Set<WidgetState> states,
        ) {
          if (states.contains(WidgetState.selected)) {
            return AppColors.softBlue;
          }
          return Colors.grey.shade400;
        }),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      ),
    );
  }

  /// Update setting with visual feedback - Requirements 13.3: Implement setting persistence with visual feedback
  void _updateSetting(VoidCallback updateFunction) {
    setState(() {
      updateFunction();
    });

    // Show visual feedback
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.white, size: 20),
            SizedBox(width: 12),
            Text('Setting saved successfully'),
          ],
        ),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        backgroundColor: AppColors.success,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }
}
