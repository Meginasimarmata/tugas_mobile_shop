import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:online_shop/routes/route_arguments.dart';
import 'package:online_shop/routes/app_routes.dart';
import 'package:online_shop/themes/app_colors.dart';
import 'package:online_shop/widgets/custom_button.dart';
import 'package:online_shop/data/dummy_data_provider.dart';
import 'package:intl/intl.dart';

/// ProductDetailScreen displays detailed information about a product
/// with role-based UI elements for buyers and sellers.
class ProductDetailScreen extends StatefulWidget {
  const ProductDetailScreen({super.key});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  final _dataProvider = DummyDataProvider();
  bool _isAddingToCart = false;

  void _handleAddToCart(BuildContext context) {
    final args =
        ModalRoute.of(context)?.settings.arguments as ProductDetailArguments?;

    if (args == null) return;

    setState(() {
      _isAddingToCart = true;
    });

    // Add to cart
    _dataProvider.addToCart(args.product);

    // Show success feedback
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${args.product.name} added to cart'),
        backgroundColor: AppColors.success,
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
      ),
    );

    setState(() {
      _isAddingToCart = false;
    });
  }

  void _handleEdit(BuildContext context) async {
    final args =
        ModalRoute.of(context)?.settings.arguments as ProductDetailArguments?;

    if (args == null) return;

    final result = await Navigator.pushNamed(
      context,
      AppRoutes.editProduct,
      arguments: EditProductArguments(product: args.product),
    );

    // If edit was successful, go back to refresh the list
    if (result == true && mounted) {
      Navigator.pop(context, true);
    }
  }

  void _handleDelete(BuildContext context) {
    final args =
        ModalRoute.of(context)?.settings.arguments as ProductDetailArguments?;

    if (args == null) return;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.error.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(
                Icons.warning_rounded,
                color: AppColors.error,
                size: 24,
              ),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Text(
                'Delete Product',
                style: TextStyle(fontSize: 18),
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Are you sure you want to delete "${args.product.name}"?',
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 8),
            const Text(
              'This action cannot be undone.',
              style: TextStyle(
                fontSize: 14,
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              // Delete product from data provider
              _dataProvider.deleteProduct(args.product.id);

              Navigator.pop(context); // Close dialog
              Navigator.pop(context, true); // Go back and refresh

              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Product deleted successfully'),
                  backgroundColor: AppColors.success,
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.error,
              foregroundColor: AppColors.white,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  String _formatCurrency(double amount) {
    final formatter = NumberFormat.currency(
      locale: 'id_ID',
      symbol: 'Rp ',
      decimalDigits: 0,
    );
    return formatter.format(amount);
  }

  @override
  Widget build(BuildContext context) {
    // Extract route arguments
    final args =
        ModalRoute.of(context)?.settings.arguments as ProductDetailArguments?;

    // Debug print
    debugPrint('ProductDetailScreen - args: $args');
    debugPrint('ProductDetailScreen - product: ${args?.product.name}');
    debugPrint('ProductDetailScreen - userRole: ${args?.userRole}');

    if (args == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Product Detail')),
        body: const Center(child: Text('No product data available')),
      );
    }

    final product = args.product;
    final userRole = args.userRole;
    final isSeller = userRole == 'seller';

    return Scaffold(
      backgroundColor: AppColors.white,
      appBar: AppBar(
        backgroundColor: AppColors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Product Detail',
          style: TextStyle(
            color: AppColors.textPrimary,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: Column(
        children: [
          // Scrollable content
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Full-width product image
                  Hero(
                    tag: 'product-${product.id}',
                    child: CachedNetworkImage(
                      imageUrl: product.imageUrl,
                      width: double.infinity,
                      height: 300,
                      fit: BoxFit.cover,
                      placeholder: (context, url) => Container(
                        width: double.infinity,
                        height: 300,
                        color: AppColors.softGrey,
                        child: const Center(child: CircularProgressIndicator()),
                      ),
                      errorWidget: (context, url, error) => Container(
                        width: double.infinity,
                        height: 300,
                        color: AppColors.softGrey,
                        child: const Icon(
                          Icons.image_not_supported,
                          size: 64,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ),
                  ),

                  // Product information
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Product name
                        Text(
                          product.name,
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 12),

                        // Price and stock row
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            // Price
                            Text(
                              _formatCurrency(product.price),
                              style: const TextStyle(
                                fontSize: 28,
                                fontWeight: FontWeight.bold,
                                color: AppColors.softBlue,
                              ),
                            ),

                            // Stock badge
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: product.stock > 0
                                    ? AppColors.success.withValues(alpha: 0.1)
                                    : AppColors.error.withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    product.stock > 0
                                        ? Icons.check_circle
                                        : Icons.cancel,
                                    size: 16,
                                    color: product.stock > 0
                                        ? AppColors.success
                                        : AppColors.error,
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    'Stock: ${product.stock}',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      color: product.stock > 0
                                          ? AppColors.success
                                          : AppColors.error,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),

                        // Category
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: AppColors.softPurple.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            product.category,
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: AppColors.softPurple,
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),

                        // Description section
                        const Text(
                          'Description',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          product.description,
                          style: const TextStyle(
                            fontSize: 16,
                            height: 1.6,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ).animate().fadeIn(duration: 400.ms, curve: Curves.easeOut),
            ),
          ),

          // Fixed bottom action buttons
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 10,
                  offset: const Offset(0, -5),
                ),
              ],
            ),
            child: SafeArea(
              child: !isSeller
                  ? // Buyer view: Add to Cart button
                  CustomButton(
                      text: 'Add to Cart',
                      onPressed: product.stock > 0
                          ? () => _handleAddToCart(context)
                          : null,
                      isLoading: _isAddingToCart,
                      width: double.infinity,
                      backgroundColor: product.stock > 0
                          ? AppColors.softBlue
                          : AppColors.textSecondary,
                    )
                  : // Seller view: Edit and Delete buttons
                  Row(
                      children: [
                        Expanded(
                          child: CustomButton(
                            text: 'Edit',
                            onPressed: () => _handleEdit(context),
                            backgroundColor: AppColors.softBlue,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: CustomButton(
                            text: 'Delete',
                            onPressed: () => _handleDelete(context),
                            backgroundColor: AppColors.error,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ],
      ),
    );
  }
}
