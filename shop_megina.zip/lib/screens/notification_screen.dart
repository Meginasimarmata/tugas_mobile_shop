import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../themes/app_colors.dart';
import '../data/dummy_data_provider.dart';
import '../models/notification_item.dart';
import '../widgets/empty_state.dart';
import '../routes/app_routes.dart';

/// NotificationScreen displays a list of notifications with
/// icon, title, message, and timestamp. Supports marking as read
/// and navigation to relevant pages.
class NotificationScreen extends StatefulWidget {
  final bool showAppBar;
  final String? userRole; // 'buyer' or 'seller'

  const NotificationScreen({
    super.key,
    this.showAppBar = true,
    this.userRole,
  });

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  final DummyDataProvider _dataProvider = DummyDataProvider();
  late List<NotificationItem> _notifications;

  @override
  void initState() {
    super.initState();
    _notifications = _getFilteredNotifications();
  }

  List<NotificationItem> _getFilteredNotifications() {
    final allNotifications = _dataProvider.notifications;
    final userRole = widget.userRole;

    // If no role specified, show all notifications
    if (userRole == null) {
      return List.from(allNotifications);
    }

    // Filter notifications based on user role
    if (userRole == 'buyer') {
      // Buyer should only see: payment notifications
      return allNotifications.where((n) => n.type == 'payment').toList();
    } else if (userRole == 'seller') {
      // Seller sees all notifications
      return List.from(allNotifications);
    }

    return List.from(allNotifications);
  }

  void _handleNotificationTap(NotificationItem notification) {
    // Mark notification as read
    setState(() {
      final index = _notifications.indexWhere((n) => n.id == notification.id);
      if (index >= 0 && !_notifications[index].isRead) {
        _notifications[index] = NotificationItem(
          id: notification.id,
          title: notification.title,
          message: notification.message,
          timestamp: notification.timestamp,
          isRead: true,
          type: notification.type,
        );
      }
    });

    // Navigate to relevant page based on notification type
    _navigateBasedOnType(notification.type);
  }

  void _navigateBasedOnType(String type) {
    switch (type) {
      case 'order':
      case 'payment':
        Navigator.pushNamed(context, AppRoutes.transactionHistory);
        break;
      case 'sale':
        Navigator.pushNamed(context, AppRoutes.sellerDashboard);
        break;
      case 'promotion':
        Navigator.pushNamed(context, AppRoutes.productList);
        break;
      default:
        // Stay on notification screen for unknown types
        break;
    }
  }

  IconData _getIconForType(String type) {
    switch (type) {
      case 'order':
        return Icons.shopping_bag_outlined;
      case 'payment':
        return Icons.payment_outlined;
      case 'sale':
        return Icons.sell_outlined;
      case 'promotion':
        return Icons.local_offer_outlined;
      default:
        return Icons.notifications_outlined;
    }
  }

  Color _getColorForType(String type) {
    switch (type) {
      case 'order':
        return AppColors.softBlue;
      case 'payment':
        return AppColors.success;
      case 'sale':
        return AppColors.softPurple;
      case 'promotion':
        return AppColors.warning;
      default:
        return AppColors.textSecondary;
    }
  }

  String _formatTimestamp(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inMinutes < 60) {
      return '${difference.inMinutes} minutes ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours} hours ago';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return '${timestamp.day}/${timestamp.month}/${timestamp.year}';
    }
  }

  @override
  Widget build(BuildContext context) {
    final body = Container(
      color: AppColors.softGrey,
      child: _notifications.isEmpty
          ? const EmptyState(
              icon: Icons.notifications_none_outlined,
              message: 'No notifications yet',
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _notifications.length,
              itemBuilder: (context, index) {
                final notification = _notifications[index];
                return _buildNotificationCard(notification, index);
              },
            ),
    );

    if (!widget.showAppBar) {
      return body;
    }

    return Scaffold(
      backgroundColor: AppColors.softGrey,
      appBar: AppBar(
        backgroundColor: AppColors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Notifications',
          style: TextStyle(
            color: AppColors.textPrimary,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: body,
    );
  }

  Widget _buildNotificationCard(NotificationItem notification, int index) {
    final isUnread = !notification.isRead;
    final iconColor = _getColorForType(notification.type);
    final icon = _getIconForType(notification.type);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: isUnread
            ? AppColors.softBlue.withValues(alpha: 0.05)
            : AppColors.white,
        borderRadius: BorderRadius.circular(16),
        border: isUnread
            ? Border.all(
                color: AppColors.softBlue.withValues(alpha: 0.2),
                width: 1,
              )
            : null,
      ),
      child: InkWell(
        onTap: () => _handleNotificationTap(notification),
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Icon
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: iconColor.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: iconColor, size: 24),
              ),
              const SizedBox(width: 16),
              // Content
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Title with unread indicator
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            notification.title,
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: isUnread
                                  ? FontWeight.bold
                                  : FontWeight.w600,
                              color: AppColors.textPrimary,
                            ),
                          ),
                        ),
                        if (isUnread)
                          Container(
                            width: 8,
                            height: 8,
                            decoration: const BoxDecoration(
                              color: AppColors.softBlue,
                              shape: BoxShape.circle,
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    // Message
                    Text(
                      notification.message,
                      style: TextStyle(
                        fontSize: 14,
                        color: AppColors.textSecondary,
                        fontWeight: isUnread
                            ? FontWeight.w500
                            : FontWeight.normal,
                      ),
                    ),
                    const SizedBox(height: 8),
                    // Timestamp
                    Text(
                      _formatTimestamp(notification.timestamp),
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    ).animate().fadeIn(duration: 300.ms, delay: (index * 50).ms);
  }
}
