import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../data/dummy_data_provider.dart';
import '../models/cart_item.dart';
import '../themes/app_colors.dart';
import '../widgets/empty_state.dart';
import '../widgets/custom_button.dart';
import '../routes/app_routes.dart';

/// CartScreen displays the shopping cart with items, quantities, and total price.
/// Users can increment/decrement quantities, remove items, and proceed to checkout.
class CartScreen extends StatefulWidget {
  final bool showAppBar;

  const CartScreen({super.key, this.showAppBar = true});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final DummyDataProvider _dataProvider = DummyDataProvider();

  @override
  Widget build(BuildContext context) {
    final cartItems = _dataProvider.cart;
    final cartTotal = _dataProvider.getCartTotal();

    final body = cartItems.isEmpty
        ? EmptyState(
            icon: Icons.shopping_cart_outlined,
            message: 'Keranjang belanja Anda kosong',
            actionText: 'Mulai Belanja',
            onAction: widget.showAppBar
                ? () {
                    Navigator.pop(context);
                  }
                : null,
          )
        : Column(
            children: [
              // Cart items list
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: cartItems.length,
                  itemBuilder: (context, index) {
                    final cartItem = cartItems[index];
                    return _buildCartItemCard(cartItem);
                  },
                ),
              ),
              // Bottom section with total and checkout button
              _buildBottomSection(cartTotal),
            ],
          );

    if (!widget.showAppBar) {
      return body;
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Keranjang Belanja'),
        backgroundColor: AppColors.white,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.softGrey, height: 1),
        ),
      ),
      body: body,
    );
  }

  Widget _buildCartItemCard(CartItem cartItem) {
    final product = cartItem.product;

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Product image
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: CachedNetworkImage(
                imageUrl: product.imageUrl,
                width: 80,
                height: 80,
                fit: BoxFit.cover,
                placeholder: (context, url) => Container(
                  width: 80,
                  height: 80,
                  color: AppColors.softGrey,
                  child: const Center(
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                ),
                errorWidget: (context, url, error) => Container(
                  width: 80,
                  height: 80,
                  color: AppColors.softGrey,
                  child: const Icon(Icons.image_not_supported),
                ),
              ),
            ),
            const SizedBox(width: 12),
            // Product details
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Product name
                  Text(
                    product.name,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  // Product price
                  Text(
                    'Rp ${_formatPrice(product.price)}',
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: AppColors.softBlue,
                    ),
                  ),
                  const SizedBox(height: 8),
                  // Quantity controls and delete button
                  Row(
                    children: [
                      // Quantity controls
                      _buildQuantityControls(cartItem),
                      const Spacer(),
                      // Delete button
                      IconButton(
                        onPressed: () => _removeFromCart(product.id),
                        icon: const Icon(Icons.delete_outline),
                        color: AppColors.error,
                        iconSize: 20,
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuantityControls(CartItem cartItem) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.softGrey, width: 1.5),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Decrement button
          InkWell(
            onTap: () => _decrementQuantity(cartItem),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(8),
              bottomLeft: Radius.circular(8),
            ),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              child: const Icon(
                Icons.remove,
                size: 18,
                color: AppColors.textPrimary,
              ),
            ),
          ),
          // Quantity display
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: const BoxDecoration(
              border: Border(
                left: BorderSide(color: AppColors.softGrey, width: 1.5),
                right: BorderSide(color: AppColors.softGrey, width: 1.5),
              ),
            ),
            child: Text(
              '${cartItem.quantity}',
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: AppColors.textPrimary,
              ),
            ),
          ),
          // Increment button
          InkWell(
            onTap: () => _incrementQuantity(cartItem),
            borderRadius: const BorderRadius.only(
              topRight: Radius.circular(8),
              bottomRight: Radius.circular(8),
            ),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              child: const Icon(
                Icons.add,
                size: 18,
                color: AppColors.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomSection(double cartTotal) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Total price row
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Total',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textPrimary,
                  ),
                ),
                Text(
                  'Rp ${_formatPrice(cartTotal)}',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: AppColors.softBlue,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            // Checkout button
            CustomButton(
              text: 'Checkout',
              onPressed: () {
                Navigator.pushNamed(context, AppRoutes.checkout);
              },
              width: double.infinity,
            ),
          ],
        ),
      ),
    );
  }

  void _incrementQuantity(CartItem cartItem) {
    setState(() {
      _dataProvider.updateCartQuantity(
        cartItem.product.id,
        cartItem.quantity + 1,
      );
    });
  }

  void _decrementQuantity(CartItem cartItem) {
    setState(() {
      if (cartItem.quantity > 1) {
        _dataProvider.updateCartQuantity(
          cartItem.product.id,
          cartItem.quantity - 1,
        );
      } else {
        // If quantity is 1, show confirmation before removing
        _showRemoveConfirmation(cartItem.product.id);
      }
    });
  }

  void _removeFromCart(String productId) {
    _showRemoveConfirmation(productId);
  }

  void _showRemoveConfirmation(String productId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Item'),
        content: const Text(
          'Apakah Anda yakin ingin menghapus item ini dari keranjang?',
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                _dataProvider.removeFromCart(productId);
              });
              Navigator.pop(context);
            },
            child: const Text(
              'Hapus',
              style: TextStyle(color: AppColors.error),
            ),
          ),
        ],
      ),
    );
  }

  String _formatPrice(double price) {
    return price
        .toStringAsFixed(0)
        .replaceAllMapped(
          RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
          (Match m) => '${m[1]}.',
        );
  }
}
