import 'package:flutter/material.dart';
import '../widgets/stat_card.dart';
import '../widgets/product_card.dart';
import '../widgets/empty_state.dart';
import '../data/dummy_data_provider.dart';
import '../models/product.dart';
import '../themes/app_colors.dart';
import '../routes/app_routes.dart';
import '../routes/route_arguments.dart';
import '../screens/profile_screen.dart';
import '../screens/notification_screen.dart';

/// SellerDashboardScreen displays the seller's dashboard with statistics
/// and product management features
class SellerDashboardScreen extends StatefulWidget {
  const SellerDashboardScreen({super.key});

  @override
  State<SellerDashboardScreen> createState() => _SellerDashboardScreenState();
}

class _SellerDashboardScreenState extends State<SellerDashboardScreen> {
  final DummyDataProvider _dataProvider = DummyDataProvider();
  int _selectedIndex = 0;

  // For demo purposes, we'll use the first seller
  String get _currentSellerId => '1';

  List<Product> get _sellerProducts {
    return _dataProvider.getProductsBySeller(_currentSellerId);
  }

  int get _totalStock {
    return _sellerProducts.fold(0, (sum, product) => sum + product.stock);
  }

  // Calculate total products sold (for demo, we'll use a simple calculation)
  int get _totalSold {
    // In a real app, this would come from transaction data
    // For now, we'll calculate based on initial stock vs current stock
    return _sellerProducts.length * 2; // Demo value
  }

  void _onBottomNavTap(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void _navigateToProductDetail(Product product) async {
    await NavigationHelper.navigateToProductDetail(
      context,
      product: product,
      userRole: 'seller',
    );
    // Refresh state after returning
    setState(() {});
  }

  void _navigateToAddProduct() async {
    await Navigator.pushNamed(context, AppRoutes.addProduct);
    // Refresh state after returning
    setState(() {});
  }

  Widget _buildDashboardPage() {
    return RefreshIndicator(
      onRefresh: () async {
        // Simulate refresh
        await Future.delayed(const Duration(seconds: 1));
        setState(() {});
      },
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Statistics Cards
            Row(
              children: [
                Expanded(
                  child: StatCard(
                    title: 'Total Sold',
                    value: _totalSold.toString(),
                    icon: Icons.shopping_bag,
                    color: AppColors.softBlue,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: StatCard(
                    title: 'Stock Count',
                    value: _totalStock.toString(),
                    icon: Icons.inventory,
                    color: AppColors.softPurple,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Products Section Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'My Products',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textPrimary,
                  ),
                ),
                TextButton.icon(
                  onPressed: () async {
                    await Navigator.pushNamed(context, AppRoutes.productList);
                    setState(() {});
                  },
                  icon: const Icon(Icons.list, size: 18),
                  label: const Text('View All'),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Products Grid
            _sellerProducts.isEmpty
                ? const EmptyState(
                    icon: Icons.inventory_2_outlined,
                    message: 'No products yet. Add your first product!',
                  )
                : GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 0.75,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                    ),
                    itemCount: _sellerProducts.length,
                    itemBuilder: (context, index) {
                      final product = _sellerProducts[index];
                      return ProductCard(
                        product: product,
                        onTap: () => _navigateToProductDetail(product),
                      );
                    },
                  ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Define page titles
    const pageTitles = ['Dashboard', 'Profile', 'Notifications'];

    return Scaffold(
      backgroundColor: AppColors.softGrey,
      appBar: AppBar(
        backgroundColor: AppColors.white,
        elevation: 0,
        automaticallyImplyLeading: false, // Remove back button
        title: Text(
          pageTitles[_selectedIndex],
          style: const TextStyle(
            color: AppColors.textPrimary,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: _selectedIndex == 0
            ? [
                IconButton(
                  icon: const Icon(Icons.notifications_outlined),
                  color: AppColors.textPrimary,
                  onPressed: () {
                    setState(() {
                      _selectedIndex = 2; // Switch to notifications tab
                    });
                  },
                ),
              ]
            : null,
      ),
      body: IndexedStack(
        index: _selectedIndex,
        children: [
          _buildDashboardPage(),
          const ProfileScreen(showAppBar: false),
          const NotificationScreen(showAppBar: false, userRole: 'seller'),
        ],
      ),
      floatingActionButton: _selectedIndex == 0
          ? FloatingActionButton.extended(
              onPressed: _navigateToAddProduct,
              backgroundColor: AppColors.softBlue,
              icon: const Icon(Icons.add),
              label: const Text('Add Product'),
            )
          : null,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onBottomNavTap,
        selectedItemColor: AppColors.softBlue,
        unselectedItemColor: AppColors.textSecondary,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
          BottomNavigationBarItem(
            icon: Icon(Icons.notifications),
            label: 'Notifications',
          ),
        ],
      ),
    );
  }
}
