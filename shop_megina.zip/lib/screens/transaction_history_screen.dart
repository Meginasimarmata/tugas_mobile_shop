import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/transaction.dart';
import '../models/user.dart';
import '../data/dummy_data_provider.dart';
import '../widgets/empty_state.dart';
import '../themes/app_colors.dart';
import '../routes/route_arguments.dart';

/// TransactionHistoryScreen displays the list of transactions
/// filtered by user role (buyer or seller)
class TransactionHistoryScreen extends StatefulWidget {
  const TransactionHistoryScreen({super.key});

  @override
  State<TransactionHistoryScreen> createState() =>
      _TransactionHistoryScreenState();
}

class _TransactionHistoryScreenState extends State<TransactionHistoryScreen> {
  final DummyDataProvider _dataProvider = DummyDataProvider();
  late User _currentUser;
  late List<Transaction> _filteredTransactions;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _loadTransactions();
  }

  void _loadTransactions() {
    // Get current user from route arguments or use default
    final args = ModalRoute.of(context)?.settings.arguments as User?;
    _currentUser = args ?? _dataProvider.users[1]; // Default to Siti Buyer

    // Filter transactions based on user role
    if (_currentUser.role == 'seller') {
      // Show sales transactions for seller
      _filteredTransactions = _dataProvider.getTransactionsBySeller(
        _currentUser.id,
      );
    } else {
      // Show purchase transactions for buyer
      _filteredTransactions = _dataProvider.getTransactionsByBuyer(
        _currentUser.id,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.white),
          onPressed: () {
            // Navigate back to buyer dashboard or previous screen
            Navigator.of(context).popUntil((route) => route.isFirst || route.settings.name == '/buyer-dashboard');
          },
        ),
        title: const Text(
          'Riwayat Transaksi',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: AppColors.softBlue,
        foregroundColor: AppColors.white,
      ),
      body: _filteredTransactions.isEmpty
          ? EmptyState(
              icon: Icons.receipt_long_outlined,
              message: _currentUser.role == 'seller'
                  ? 'Belum ada transaksi penjualan'
                  : 'Belum ada transaksi pembelian',
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _filteredTransactions.length,
              itemBuilder: (context, index) {
                final transaction = _filteredTransactions[index];
                return _TransactionCard(
                  transaction: transaction,
                  userRole: _currentUser.role,
                  onTap: () {
                    NavigationHelper.navigateToTransactionDetail(
                      context,
                      transaction: transaction,
                    );
                  },
                );
              },
            ),
    );
  }
}

/// _TransactionCard displays a single transaction item
class _TransactionCard extends StatelessWidget {
  final Transaction transaction;
  final String userRole;
  final VoidCallback onTap;

  const _TransactionCard({
    required this.transaction,
    required this.userRole,
    required this.onTap,
  });

  String _getProductNames() {
    if (transaction.items.isEmpty) {
      return 'No items';
    }
    if (transaction.items.length == 1) {
      return transaction.items[0].product.name;
    }
    return '${transaction.items[0].product.name} +${transaction.items.length - 1} lainnya';
  }

  String _formatDate(DateTime date) {
    return DateFormat('dd MMM yyyy, HH:mm').format(date);
  }

  String _formatCurrency(double amount) {
    final formatter = NumberFormat.currency(
      locale: 'id_ID',
      symbol: 'Rp ',
      decimalDigits: 0,
    );
    return formatter.format(amount);
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Transaction ID and Date
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'ID: ${transaction.id}',
                    style: const TextStyle(
                      fontSize: 12,
                      color: AppColors.textSecondary,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.success.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      transaction.status.toUpperCase(),
                      style: const TextStyle(
                        fontSize: 10,
                        color: AppColors.success,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              // Date
              Row(
                children: [
                  const Icon(
                    Icons.calendar_today,
                    size: 14,
                    color: AppColors.textSecondary,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    _formatDate(transaction.date),
                    style: const TextStyle(
                      fontSize: 12,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              // Product Names
              Text(
                _getProductNames(),
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textPrimary,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 8),
              // Payment Method
              Row(
                children: [
                  const Icon(
                    Icons.payment,
                    size: 14,
                    color: AppColors.textSecondary,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    transaction.paymentMethod,
                    style: const TextStyle(
                      fontSize: 12,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              const Divider(height: 1),
              const SizedBox(height: 12),
              // Total Amount
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Total',
                    style: TextStyle(
                      fontSize: 14,
                      color: AppColors.textSecondary,
                    ),
                  ),
                  Text(
                    _formatCurrency(transaction.totalAmount),
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: AppColors.softBlue,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
