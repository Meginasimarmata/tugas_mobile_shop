import 'package:flutter/material.dart';
import '../widgets/custom_button.dart';
import '../widgets/custom_text_field.dart';
import '../themes/app_colors.dart';
import '../data/dummy_data_provider.dart';
import '../models/product.dart';
import '../routes/app_routes.dart';

/// AddProductScreen allows sellers to add new products with validation
class AddProductScreen extends StatefulWidget {
  const AddProductScreen({super.key});

  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _priceController = TextEditingController();
  final _stockController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _categoryController = TextEditingController();

  String? _selectedImageUrl;
  bool _isLoading = false;

  @override
  void dispose() {
    _nameController.dispose();
    _priceController.dispose();
    _stockController.dispose();
    _descriptionController.dispose();
    _categoryController.dispose();
    super.dispose();
  }

  // Validator for empty fields
  String? _validateRequired(String? value, String fieldName) {
    if (value == null || value.trim().isEmpty) {
      return '$fieldName is required';
    }
    return null;
  }

  // Validator for price (numeric and positive)
  String? _validatePrice(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Price is required';
    }

    final price = double.tryParse(value);
    if (price == null) {
      return 'Please enter a valid price';
    }

    if (price <= 0) {
      return 'Price must be greater than 0';
    }

    return null;
  }

  // Validator for stock (non-negative)
  String? _validateStock(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Stock is required';
    }

    final stock = int.tryParse(value);
    if (stock == null) {
      return 'Please enter a valid stock number';
    }

    if (stock < 0) {
      return 'Stock must be 0 or greater';
    }

    return null;
  }

  // Handle image picker tap
  void _handleImagePicker() {
    // Show feedback on tap
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Image picker functionality'),
        duration: Duration(seconds: 1),
      ),
    );

    // For demo purposes, use a placeholder image
    setState(() {
      _selectedImageUrl =
          'https://picsum.photos/seed/${DateTime.now().millisecondsSinceEpoch}/400/400';
    });
  }

  // Handle form submission
  void _handleSubmit() async {
    if (_formKey.currentState!.validate()) {
      // Check if image is selected
      if (_selectedImageUrl == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Please select a product image'),
            backgroundColor: AppColors.error,
          ),
        );
        return;
      }

      setState(() {
        _isLoading = true;
      });

      // Simulate API call delay
      await Future.delayed(const Duration(milliseconds: 500));

      // Create new product
      final newProduct = Product(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: _nameController.text.trim(),
        description: _descriptionController.text.trim(),
        price: double.parse(_priceController.text),
        stock: int.parse(_stockController.text),
        imageUrl: _selectedImageUrl!,
        category: _categoryController.text.trim().isEmpty
            ? 'General'
            : _categoryController.text.trim(),
        sellerId: '1', // Using dummy seller ID
      );

      // Add product to dummy data
      DummyDataProvider().products.add(newProduct);

      setState(() {
        _isLoading = false;
      });

      // Show success feedback
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Product added successfully!'),
            backgroundColor: AppColors.success,
          ),
        );

        // Navigate back to seller dashboard
        Navigator.of(context).pushReplacementNamed(AppRoutes.sellerDashboard);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.softGrey,
      appBar: AppBar(
        title: const Text('Add Product'),
        backgroundColor: AppColors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: AppColors.textPrimary),
        titleTextStyle: const TextStyle(
          color: AppColors.textPrimary,
          fontSize: 18,
          fontWeight: FontWeight.w600,
        ),
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Image picker section
              GestureDetector(
                onTap: _handleImagePicker,
                child: Container(
                  height: 200,
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: AppColors.softBlue.withValues(alpha: 0.3),
                      width: 2,
                      strokeAlign: BorderSide.strokeAlignInside,
                    ),
                  ),
                  child: _selectedImageUrl == null
                      ? Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.add_photo_alternate_outlined,
                              size: 64,
                              color: AppColors.softBlue.withValues(alpha: 0.5),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Tap to select product image',
                              style: TextStyle(
                                color: AppColors.textSecondary.withValues(
                                  alpha: 0.7,
                                ),
                                fontSize: 14,
                              ),
                            ),
                          ],
                        )
                      : ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.network(
                            _selectedImageUrl!,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) {
                              return const Center(
                                child: Icon(
                                  Icons.error_outline,
                                  size: 48,
                                  color: AppColors.error,
                                ),
                              );
                            },
                          ),
                        ),
                ),
              ),
              const SizedBox(height: 24),

              // Product name field
              CustomTextField(
                label: 'Product Name',
                hint: 'Enter product name',
                controller: _nameController,
                validator: (value) => _validateRequired(value, 'Product name'),
              ),
              const SizedBox(height: 16),

              // Price field
              CustomTextField(
                label: 'Price',
                hint: 'Enter price',
                controller: _priceController,
                keyboardType: TextInputType.number,
                validator: _validatePrice,
                prefixIcon: const Icon(Icons.attach_money, size: 20),
              ),
              const SizedBox(height: 16),

              // Stock field
              CustomTextField(
                label: 'Stock',
                hint: 'Enter stock quantity',
                controller: _stockController,
                keyboardType: TextInputType.number,
                validator: _validateStock,
                prefixIcon: const Icon(Icons.inventory_2_outlined, size: 20),
              ),
              const SizedBox(height: 16),

              // Category field
              CustomTextField(
                label: 'Category',
                hint: 'Enter category (optional)',
                controller: _categoryController,
              ),
              const SizedBox(height: 16),

              // Description field
              CustomTextField(
                label: 'Description',
                hint: 'Enter product description',
                controller: _descriptionController,
                maxLines: 4,
                validator: (value) => _validateRequired(value, 'Description'),
              ),
              const SizedBox(height: 32),

              // Save button
              CustomButton(
                text: 'Save Product',
                onPressed: _handleSubmit,
                isLoading: _isLoading,
                width: double.infinity,
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}
